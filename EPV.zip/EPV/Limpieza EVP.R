EPV2024 <- Base_EPV_2024_anonimizada[Base_EPV_2024_anonimizada$MUNICIPIO == 11001, ]
EPV2024[, 11:358][is.na(EPV2024[, 11:285])] <- 0

EPV2023 <- Base2023
EPV2023[, 8:133] <- lapply(EPV2023[, 8:133], as.numeric)
EPV2023[, 8:133][is.na(EPV2023[, 8:133])] <- 0

EPV2022 <- Base2022
EPV2022[, 6:124] <- lapply(EPV2022[, 6:124], as.numeric)
EPV2022[, 6:124][is.na(EPV2022[, 6:124])] <- 0

EPV2021 <- Base2021
EPV2021[, 14:184] <- lapply(EPV2021[, 14:184], as.numeric)
EPV2021[, 14:184][is.na(EPV2021[, 14:184])] <- 0

EPV2020 <- Base_2020

EPV2019_2 <- Base2019_2
EPV2019_2[, 2:299] <- lapply(EPV2019_2[, 2:299], as.numeric)
EPV2019_2[, 2:299][is.na(EPV2019_2[, 2:299])] <- 0

EPV2019_1 <- Base2019_1
EPV2019_1[, 2:140] <- lapply(EPV2019_1[, 2:140], as.numeric)
EPV2019_1[, 2:140][is.na(EPV2019_1[, 2:140])] <- 0

write.csv(EPV2024, file = "C:/Users/Asus/Documents/2025/DataJam/EPV2024.csv", row.names = FALSE)

datasets <- list(EPV2024 = EPV2024, EPV2023 = EPV2023, EPV2022 = EPV2022, 
                 EPV2021 = EPV2021, EPV2020 = EPV2020, EPV2019_2 = EPV2019_2, 
                 EPV2019_1 = EPV2019_1)
# Iterar sobre los datasets y exportarlos
for (nombre in names(datasets)) {
  write.csv(datasets[[nombre]], file = paste0("C:/Users/Asus/Documents/2025/DataJam/EPV2024.csv", nombre, ".csv"), row.names = FALSE)
}

